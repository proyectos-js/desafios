numero = ARGV[0].to_i

i=1

numero.times do |cont|
    if i%2==0
       puts i
          
     end
     i=i+1
end

 