 50.times do |i|
    puts "iteracion #{i}"
    end